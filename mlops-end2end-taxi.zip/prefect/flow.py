from prefect import flow, task
import subprocess

@task
def run_training():
    subprocess.run(["python", "src/train.py"], check=True)

@flow
def training_pipeline():
    run_training()

if __name__ == "__main__":
    training_pipeline()
