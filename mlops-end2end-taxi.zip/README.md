# MLOps End-to-End Pipeline – NYC Taxi Trip Duration

This project demonstrates an end-to-end MLOps workflow including model training, experiment tracking, orchestration, containerization, and monitoring.

## Tools Used
- Python, Pandas, Scikit-Learn
- MLflow for tracking
- Docker for containerization
- Prefect for orchestration
- Prometheus + Grafana for monitoring

## Pipeline Stages
1. Data ingestion and preprocessing
2. Model training with Scikit-Learn
3. Metric tracking with MLflow
4. Deployment via Docker
5. Orchestration using Prefect
6. Drift monitoring with Prometheus

## Usage
```bash
python src/train.py
python prefect/flow.py
```

## Author
[Jayasudhaa Tiru](https://github.com/Jayasudhaa)
